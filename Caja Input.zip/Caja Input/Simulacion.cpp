#include "Simulacion.h"

//Constructor: Acepta como par�metros la dimension y el nombre de la ventana para el programa. Inicializa las variables y
//llama a m�todos de inicializaci�n
Simulacion::Simulacion(Vector2i dimensiones_programa, string nombre_programa) {

	//Iguala la variable de vector de dimension
	dimensiones_ventana = dimensiones_programa;

	//Iguala la variable de nombre
	nombre_ventana = nombre_programa;

	//Asigna una nueva ventana a la variable existente
	ventana = crearVentana(dimensiones_ventana.x, dimensiones_ventana.y, nombre_ventana);

	//Instancia el gestor de eventos
	gestor_eventos = new Event;

	//Se establece la gravedad y se suministra al mundo f�sico para su creaci�n
	gravedad = {0.0f, 0.05f};
	mundo = new b2World(gravedad);

	//Llamada a crear los elementos
	crearElementos();

}

//M�todo que llena los punteros a elementos con valores, instancia el soporte y la bola
void Simulacion::crearElementos() {

	//SOPORTE
	b2Vec2 dimensiones_pared = { 0.5f, 9.75f };
	b2Vec2 dimensiones_suelo = { 20.0f, 0.5f };

	//Creaci�n de los delimitantes de la simulaci�n
	paredes[0] = new Poligono(dimensiones_suelo, { 19.0f, 21.0f }, mundo, Color::Blue, false, PIXELES_POR_METRO); //Suelo
	paredes[1] = new Poligono(dimensiones_suelo, { 19.0f, 0.5f }, mundo, Color::Blue, false, PIXELES_POR_METRO); //Techo
	paredes[2] = new Poligono(dimensiones_pared, { 0.5f, 10.75f }, mundo, Color::Cyan, false, PIXELES_POR_METRO); //Pared izquierda
	paredes[3] = new Poligono(dimensiones_pared, { 38.0f, 10.75f }, mundo, Color::Cyan, false, PIXELES_POR_METRO); //Pared derecha
	

	////////////////////////////////////////////////////////////////////////////

	//CAJA
	b2Vec2 dimensiones_caja = { 1.0f, 1.0f};

	//Crea la caja m�vil
	caja = new Poligono(dimensiones_caja, { 19.2f, 10.8f }, mundo, Color::White, true, PIXELES_POR_METRO);

}

//M�todo de bucle principal, en �l ocurre todo el manejo de la l�gica
void Simulacion::iniciarSimulacion() {

	//Mientras la ventana est� abierta...
	while (ventana->isOpen()) {

		//Llama a actualizar las f�sicas
		actualizarFisicas(10,8);

		//Ejecuta la gesti�n de eventos
		gestionarEventos();

		//Ejecuta la actualizaci�n del renderizado en la ventana
		actualizarRenderizado();

	}

}

//M�todo que genera una ventana con las dimensiones y nombre especificadas y luego la retorna para ser almacenada y usada
RenderWindow* Simulacion::crearVentana(int altura, int anchura, string nombre) {

	//Retorna una nueva ventana con los par�metros recibidos
	return new RenderWindow(VideoMode(anchura, altura), nombre);

}

//M�todo que recibe inserciones para dibujarlas en la pantalla, limpia y actualiza el contenido de la misma
void Simulacion::actualizarRenderizado() {

	//Limpia la pantalla
	ventana->clear();

	//Itera sobre el arreglo de paredes
	for (int i = 0; i < 4; i++) {

		//Llama a dibujar desde la pared obtenida
		paredes[i]->renderizar(ventana);

	}

	//A�ade la caja para ser dibujada
	caja->renderizar(ventana);

	//Muestra el contenido cargado
	ventana->display();

}

//M�todo encargado de procesar todos los inputs eventos del jugador sobre la ventana.
void Simulacion::gestionarEventos() {

	while (ventana->pollEvent(*gestor_eventos)) {

		switch (gestor_eventos->type) {

			//Evento: Cerrar ventana
		case Event::Closed:

			ventana->close();

			break;

			//Evento: Tecla Presionada
		case Event::KeyPressed:

			switch (gestor_eventos->key.code) {

				//Tecla: Espacio - Aplica una fuerza a la caja hacia arriba
			case Keyboard::Space:

				caja->aplicarFuerza({ 0.0f, -250.0f });

				break;

				//Tecla: Flecha Arriba - Aplica una fuerza a la caja hacia arriba
			case Keyboard::Up:

				caja->aplicarFuerza({ 0.0f, -250.0f });

				break;

				//Tecla: D - Aplica una fuerza a la caja hacia la derecha
			case Keyboard::D:

				caja->aplicarFuerza({ 75.0f, 0.0f});

				break;

				//Tecla: Flecha Derecha - Aplica una fuerza a la caja hacia la derecha
			case Keyboard::Right:

				caja->aplicarFuerza({ 75.0f, 0.0f });

				break;

				//Tecla: A - Aplica una fuerza a la caja hacia la izquierda
			case Keyboard::A:

				caja->aplicarFuerza({ -75.0f, 0.0f });

				break;

				//Tecla: Flecha Izquierda - Aplica una fuerza a la caja hacia la izquierda
			case Keyboard::Left:

				caja->aplicarFuerza({ -75.0f, 0.0f });

				break;
				
			}

		}

	}

}

//M�todo que actualiza la simulaci�n fisica usando las iteraciones suministradas por par�metro
void Simulacion::actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion) {

	//Almacena el tiempo
	float tiempo = 1.0f / 60.0f;

	//Hace que el mundo f�sico avance, actualizado los objetos contenidos en �l
	mundo->Step(tiempo, iteraciones_velocidad, iteraciones_posicion);

	//Tras actualizar las fisicas llama a la sincronizaci�n de visuales
	actualizarObjetos();

}

//Encargado de actualizar la posici�n de los objetos visuales para encajar con la de sus contrapartes f�sicas
void Simulacion::actualizarObjetos() {

	//Bucle que itera sobre todos los elementos del arreglo paredes
	for (int i = 0; i < 4; i++) {

		//Llama a actualizar la pared sobre la cual se est� iterando
		paredes[i]->actualizar(PIXELES_POR_METRO);

	}

	//Actualiza la caja
	caja->actualizar(PIXELES_POR_METRO);

}

//M�todo debug que imprime la posici�n y rotaci�n de un objeto por consola
void Simulacion::depurarTransformacion(Poligono objeto) {

	//Depura la posici�n f�sica y visual
	cout << "P. Fisica: " << objeto.retornarCuerpo()->GetPosition().x * PIXELES_POR_METRO << ", " << objeto.retornarCuerpo()->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "P. Visual: " << objeto.retornarVisual()->getPosition().x << ", " << objeto.retornarVisual()->getPosition().y << endl;

	//Depura la rotaci�n f�sica y visual
	cout << "R. Fisica: " << objeto.retornarCuerpo()->GetAngle() << endl;
	cout << "R. Visual: " << objeto.retornarVisual()->getRotation() * (b2_pi / 180.0f) << endl;

}