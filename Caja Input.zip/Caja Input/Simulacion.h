#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <box2d.h>
#include <iostream>
#include <cstdlib>

#include "Poligono.h"

using namespace std;
using namespace sf;

class Simulacion {

private:

	//Constante que define a cuantos pixeles equivale un metro
	const int PIXELES_POR_METRO = 50;

	//Variables de la ventana del programa
	Vector2i dimensiones_ventana;
	string nombre_ventana;

	//Ventana
	RenderWindow* ventana;

	//Objeto de Eventos
	Event* gestor_eventos;

	//Gravedad y mundo
	b2Vec2 gravedad;
	b2World* mundo;

	//Poligono y Circulo
	Poligono* paredes[4];
	Poligono* caja;

public:

	//Constructor
	Simulacion(Vector2i dimensiones_programa, string nombre_programa);

	//M�todos sin retorno
	void iniciarSimulacion();
	void actualizarRenderizado();
	void gestionarEventos();
	void crearElementos();
	void actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion);
	void actualizarObjetos();

	//M�todos con retorno de datos
	RenderWindow* crearVentana(int altura, int anchura, string nombre);

	//M�todos de depuraci�n
	void depurarTransformacion(Poligono objeto);

};

