#include "Poligono.h"

//Constructor Simple: Recibe un puntero al mundo f�sico donde se crear� el cuerpo, aplica datos por defecto a todo lo dem�s
Poligono::Poligono(b2World* mundo) {

	//Variable de posici�n por defecto
	b2Vec2 posicion = {0.0f, 0.0f};

	//Se asignan las dimensiones del pol�gono como por defecto (1x1 metros)
	dimensiones = { 0.5f, 0.5f };
	
	//Llamada a crear los objetos f�sicos, con los par�metros por defecto
	crearFisicas(posicion, mundo, false);

	//Llamada a crear el objeto visual, con los par�metros por defecto
	crearVisuales(Color::White, posicion, 50);

}

//Constructor Semi-Compuesto: Recibe algunos par�metros, incluyendo el mundo donde se crear� el cuerpo, su posici�n en dicho mundo
//y la escala de pixeles por metro, los dem�s par�metros permanecen en valor "por defecto"
Poligono::Poligono(b2World* mundo, b2Vec2 posicion, int pixeles_por_metro) {

	//Se asignan las dimensiones del pol�gono como por defecto (1x1 metros)
	dimensiones = { 0.5f, 0.5f };

	//Llamada a crear los objetos f�sicos, con los par�metros por defecto
	crearFisicas(posicion, mundo, false);

	//Llamada a crear el objeto visual, con los par�metros por defecto
	crearVisuales(Color::White, posicion, pixeles_por_metro);

}

//Constructor Compuesto: Recibe varios par�metros, entre ellos las dimensiones del pol�gono a crear, la posici�n, el mundo donde se
//crear�, el color del que ser� pintado, si es din�mico o est�tico y el valor de conversi�n de metros a pixeles
Poligono::Poligono(b2Vec2 dimensiones_poligono, b2Vec2 posicion, b2World* mundo, Color color, bool es_dinamico, int pixeles_por_metro) {

	//Se asignan las nuevas dimensiones a la variable
	dimensiones = dimensiones_poligono;

	//Llamada a crear los objetos f�sicos, con los par�metros personalizados
	crearFisicas(posicion, mundo, es_dinamico);

	//Llamada a crear el objeto visual, con los par�metros personalizados
	crearVisuales(color, posicion, pixeles_por_metro);

}

//M�todo encargado de generar la definici�n de cuerpo, figura f�sica, cuerpo, definici�n de fijador y fijador del poligono.
//Recibe como par�metros la posici�n donde se crear� el cuerpo, el mundo donde se crear� y un bool para determinar si es din�mico o no.
void Poligono::crearFisicas(b2Vec2 posicion, b2World* mundo, bool es_dinamico) {

	//Se establece la dimensi�n de la figura
	figura_cuerpo.SetAsBox(dimensiones.x, dimensiones.y);

	//Si el poligono debe ser din�mico...
	if (es_dinamico) {

		//Establece el tipo de cuerpo como "din�mico"
		definicion_cuerpo.type = b2_dynamicBody;

	}
	//Sino...
	else {

		//Establece el tipo de cuerpo como "est�tico"
		definicion_cuerpo.type = b2_staticBody;

	}

	//Asigna la nueva posici�n para el cuerpo
	definicion_cuerpo.position = posicion;

	//Crea el cuerpo a partir de la definici�n y lo almacena en su variable
	cuerpo = mundo->CreateBody(&definicion_cuerpo);

	//Asigna la figura a la definici�n del fijador y lo crea usando la misma
	definicion_fijador.shape = &figura_cuerpo;
	definicion_fijador.density = 1.0f;
	definicion_fijador.friction = 0.1f;
	definicion_fijador.restitution = 0.0f;
	fijador = cuerpo->CreateFixture(&definicion_fijador);

}

//M�todo encargado de crear el apartado visual del pol�gono, recibe como par�metro el color y la conversi�n de metros a pixeles
void Poligono::crearVisuales(Color color, b2Vec2 posicion, int pixeles_por_metro) {

	//Almacena vectores convertidos de vectores f�sicos a vectores gr�ficos, usando la unidad de pixel por metro
	Vector2f posicion_convertida = { posicion.x * pixeles_por_metro,posicion.y * pixeles_por_metro };
	Vector2f dimensiones_convertidas = { (dimensiones.x * 2) * pixeles_por_metro, (dimensiones.y * 2) * pixeles_por_metro};

	//Asigna los valores a cada atributo de la figura: Tama�o, Color y Posici�n
	figura_visual.setSize(dimensiones_convertidas);
	figura_visual.setFillColor(color);
	figura_visual.setOrigin(dimensiones_convertidas.x / 2, dimensiones_convertidas.y / 2);
	figura_visual.setPosition(posicion_convertida);

	//Llama a actualizar
	actualizar(pixeles_por_metro);

}

//Este m�todo usa la ventana recibida como par�metro para dibujar el Pol�gono en ella, para usarse se debe insertar entre las directivas
//de "clear" y "display"
void Poligono::renderizar(RenderWindow* ventana) {

	ventana->draw(figura_visual);

}

//Este m�todo actualiza los estados del poligono, principalmente se encarga de actualizar la posici�n del objeto visual para que encaje
//con la del objeto f�sico. Llamado tras avanzar un paso en la simulaci�n del mundo (M�todo "Step")
void Poligono::actualizar(int pixeles_por_metro) {

	//Almacena la posici�n f�sica convertida a posici�n visual (de "b2Vec2" a "Vector2f") y la rotaci�n convertida (radianes a grados)
	Vector2f posicion_fisica_convertida = { cuerpo->GetPosition().x * pixeles_por_metro, cuerpo->GetPosition().y * pixeles_por_metro};
	float rotacion_convertida = cuerpo->GetAngle() * (180.0f / b2_pi);

	//Establece la posici�n y rotaci�n con las unidades convertidas
	figura_visual.setPosition(posicion_fisica_convertida);
	figura_visual.setRotation(rotacion_convertida);

}

//Cambia la densidad con el valor suministrado por par�metro
void Poligono::modificarDensidad(float nuevo_valor) {

	//Establece la densidad nueva y llama al reseteo de la data de masa
	fijador->SetDensity(nuevo_valor);
	cuerpo->ResetMassData();

}

//Cambia la fricci�n con el valor suministrado por par�metro
void Poligono::modificarFriccion(float nuevo_valor) {

	fijador->SetFriction(nuevo_valor);

}

//Cambia la restituci�n con el valor suministrado por par�metro
void Poligono::modificarRestitucion(float nuevo_valor) {

	fijador->SetRestitution(nuevo_valor);

}

//M�todo que despierta o duerme al cuerpo, dependiendo el estado suministrado por par�metro
void Poligono::despertar(bool estado) {

	cuerpo->SetAwake(estado);

}

//M�todo que usa la magnitud suministrada para aplicar una fuerza en newtons al cuerpo, despert�ndolo en el proceso
void Poligono::aplicarFuerza(b2Vec2 magnitud) {

	cuerpo->ApplyForceToCenter(magnitud, true);

}

//////////////////////////////////////////////////////////////////

//M�todo que devuelve el cuerpo f�sico del Pol�gono
b2Body* Poligono::retornarCuerpo() {

	return cuerpo;

}

//M�todo que devuelve el cuerpo visual del Pol�gono
RectangleShape* Poligono::retornarVisual() {

	return &figura_visual;

}

//M�todo que devuelve la densidad del cuerpo f�sico
float Poligono::retornarDensidad() {

	return fijador->GetDensity();

}

//M�todo que devuelve la fricci�n del cuerpo f�sico
float Poligono::retornarFriccion() {

	return fijador->GetFriction();

}

//M�todo que devuelve la restituci�n del cuerpo f�sico
float Poligono::retornarRestitucion() {

	return fijador->GetRestitution();

}
