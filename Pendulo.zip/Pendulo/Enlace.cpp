#include "Enlace.h"

//Constructor: Recibe como par�metros los 2 Poligonos a conectar, un par de coordenadas representando el punto de anclaje de cada
//cuerpo, una referencia al mundo y la unidad de pixeles por metro para el renderizado en pantalla
Enlace::Enlace(Poligono* objeto1, Circulo* objeto2, b2Vec2 coordenadas_ancla1, b2Vec2 coordenadas_ancla2, b2World* mundo, int pixeles_por_metro) {

	//Se asignan los valores recibidos a sus variables de la clase, para manipulaci�n m�s eficiente de los datos
	objeto_a = objeto1;
	objeto_b = objeto2;
	coordenadas_ancla_a = coordenadas_ancla1;
	coordenadas_ancla_b = coordenadas_ancla2;

	//Se asignan los cuerpos a conectar
	definicion.bodyA = objeto_a->retornarCuerpo();
	definicion.bodyB = objeto_b->retornarCuerpo();

	//Se asignan los puntos de anclaje (coordenadas de offset)
	definicion.localAnchorA = coordenadas_ancla_a;
	definicion.localAnchorB = coordenadas_ancla_b;

	definicion.minLength =  1.0f;
	definicion.maxLength = 4.0f;

	//Se activa la colisi�n entre los cuerpos anclados
	definicion.collideConnected = true;

	//Se crea la junta, enviandole al mundo la directiva para crear el joint usando su definici�n
	junta = (b2DistanceJoint*)mundo->CreateJoint(&definicion);

	//Configura la Primitiva de Linea y la cantidad de v�rtices para los visuales
	puntos_visuales.setPrimitiveType(Lines);
	puntos_visuales.resize(2);

	//Bucle que itera sobre ambos puntos de la primitiva visual
	for (int i = 0; i < 2; i++) {

		//Asigna el color rojo al elemento sobre el que se itera
		puntos_visuales[i].color = Color::Green;

	}

	//Se llama a actualizar para posicionar los puntos correctamente en la pantalla
	actualizar(pixeles_por_metro);

}

//M�todo que recibe una ventana como par�metro, en la cual se dibuja la directiva gr�fica utilizada para mostrar la linea del enlace
void Enlace::renderizar(RenderWindow* ventana) {

	ventana->draw(puntos_visuales);

}

//M�todo que actualiza la posici�n de los v�rtices de la linea visual para que encajen con la posici�n f�sica de los mismos
void Enlace::actualizar(int pixeles_por_metro) {

	//Guarda la posici�n visual, usando la posici�n f�sica y sumandole el offset de los puntos de anclaje
	Vector2f posicion_visual[2];
	posicion_visual[0] = { (objeto_a->retornarCuerpo()->GetPosition().x + coordenadas_ancla_a.x) * pixeles_por_metro, (objeto_a->retornarCuerpo()->GetPosition().y + coordenadas_ancla_a.y) * pixeles_por_metro };
	posicion_visual[1] = { (objeto_b->retornarCuerpo()->GetPosition().x + coordenadas_ancla_b.x) * pixeles_por_metro, (objeto_b->retornarCuerpo()->GetPosition().y + coordenadas_ancla_b.y) * pixeles_por_metro };

	//Itera sobre ambos puntos visuales
	for (int i = 0; i < 2; i++) {

		//Establece la posici�n nueva
		puntos_visuales[i].position = posicion_visual[i];

	}

}

//////////////////////////////////////////////////////////////////////////////

//Devuelve un puntero al primer pol�gono conectado
Poligono* Enlace::retornarObjetoA() {

	return objeto_a;

}

//Devuelve un puntero al segundo pol�gono conectado
Circulo* Enlace::retornarObjetoB() {

	return objeto_b;

}
