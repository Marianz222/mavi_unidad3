#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <box2d.h>
#include <iostream>

using namespace sf;
using namespace std;

class Poligono {

private:

	//Dimensiones del poligono
	b2Vec2 dimensiones;

	//Figura visual del poligono
	RectangleShape figura_visual;

	//Figura f�sica, definicion de cuerpo y cuerpo del poligono
	b2PolygonShape figura_cuerpo;
	b2BodyDef definicion_cuerpo;
	b2Body* cuerpo;

	//Definici�n de fijador y fijador del poligono
	b2FixtureDef definicion_fijador;
	b2Fixture* fijador;

public:

	//Constructores
	Poligono(b2World* mundo);
	Poligono(b2World* mundo, b2Vec2 posicion, int pixeles_por_metro);
	Poligono(b2Vec2 dimensiones_poligono, b2Vec2 posicion, b2World* mundo, Color color, bool es_dinamico, int pixeles_por_metro);

	//M�todos sin retorno
	void renderizar(RenderWindow* ventana);
	void crearFisicas(b2Vec2 posicion, b2World* mundo, bool es_dinamico);
	void crearVisuales(Color color, b2Vec2 posicion, int pixeles_por_metro);
	void actualizar(int pixeles_por_metro);
	void modificarDensidad(float nuevo_valor);
	void modificarFriccion(float nuevo_valor);
	void modificarRestitucion(float nuevo_valor);
	void despertar(bool estado);

	//M�todos con retorno de dato
	b2Body* retornarCuerpo();
	RectangleShape* retornarVisual();
	float retornarDensidad();
	float retornarFriccion();
	float retornarRestitucion();

};

