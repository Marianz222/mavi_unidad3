#include "Circulo.h"

//Constructor Simple: Solo recibe el mundo donde se crear� el cuerpo. Genera un circulo con datos por defecto
Circulo::Circulo(b2World* mundo) {

	//Almacena la posici�n por defecto
	b2Vec2 posicion = {0.0f, 0.0f};

	//Asigna un radio por defecto
	radio = 1.0f;

	//Llama a crear f�sicas, usando posici�n y mundo pasados por par�metro pero con el estado pasado por defecto
	crearFisicas(posicion, mundo, true);

	//Llama a crear los visuales, usando un color por defecto, posici�n por referencia y escala por defecto
	crearVisuales(Color::White, posicion, 50);

}

//Constructor Compuesto: Genera un circulo personalizado, recibe su radio, su posici�n inicial, el mundo donde se crear�, el color de
//relleno, si ser� est�tico o din�mico y la escala de pixeles a metros
Circulo::Circulo(float radio, b2Vec2 posicion, b2World* mundo, Color color, bool es_dinamico, int pixeles_por_metro) {

	//Asigna el valor de radio recibido al valor de radio local de la clase
	this->radio = radio;

	//Llama a crear f�sicas con todas las propiedades suministradas
	crearFisicas(posicion, mundo, es_dinamico);

	//Llama a crear visuales con todas las propiedades suministradas
	crearVisuales(color, posicion, pixeles_por_metro);

}

//M�todo que crea el apartado f�sico del circulo, es decir su figura f�sica, fijador, cuerpo y las definiciones requeridas. Utiliza
//posicion del cuerpo a crear, mundo f�sico donde se crea y un bool que determina si ser� din�mico o est�tico.
void Circulo::crearFisicas(b2Vec2 posicion, b2World* mundo, bool es_dinamico) {

	//Se establece el radio de la figura visual
	figura_cuerpo.m_radius = radio;

	//Si el poligono debe ser din�mico...
	if (es_dinamico) {

		//Establece el tipo de cuerpo como "din�mico"
		definicion_cuerpo.type = b2_dynamicBody;

	}
	//Sino...
	else {

		//Establece el tipo de cuerpo como "est�tico"
		definicion_cuerpo.type = b2_staticBody;

	}

	//Asigna la nueva posici�n para el cuerpo
	definicion_cuerpo.position = posicion;
	definicion_cuerpo.linearDamping = 0.1f;

	//Crea el cuerpo a partir de la definici�n y lo almacena en su variable
	cuerpo = mundo->CreateBody(&definicion_cuerpo);

	//Asigna la figura a la definici�n del fijador
	definicion_fijador.shape = &figura_cuerpo;
	definicion_fijador.density = 1.0f;

	//Se crea el fijador en el cuerpo, usando la definicion
	fijador = cuerpo->CreateFixture(&definicion_fijador);

}

//Encargado de generar los datos necesarios para crear el circulo visual. Recibe color de relleno, posici�n y escala pixeles a metros
void Circulo::crearVisuales(Color color, b2Vec2 posicion, int pixeles_por_metro) {

	//Almacena vectores convertidos de vectores f�sicos a vectores gr�ficos, usando la unidad de pixel por metro
	Vector2f posicion_convertida = { posicion.x * pixeles_por_metro,posicion.y * pixeles_por_metro };
	float radio_convertido = radio * pixeles_por_metro;

	//Asigna los valores a cada atributo de la figura: Tama�o, Color y Posici�n
	circulo_visual.setRadius(radio_convertido);
	circulo_visual.setFillColor(color);
	circulo_visual.setOrigin(radio_convertido, radio_convertido);
	circulo_visual.setPosition(posicion_convertida);

	//Llama a actualizar
	actualizar(pixeles_por_metro);

}

//Este m�todo usa la ventana recibida como par�metro para dibujar el C�rculo en ella, para usarse se debe insertar entre las directivas
//de "clear" y "display"
void Circulo::renderizar(RenderWindow* ventana) {

	ventana->draw(circulo_visual);

}

//Este m�todo actualiza los estados del circulo, principalmente se encarga de actualizar la posici�n del objeto visual para que encaje
//con la del objeto f�sico. Llamado tras avanzar un paso en la simulaci�n del mundo (M�todo "Step")
void Circulo::actualizar(int pixeles_por_metro) {

	//Almacena la posici�n f�sica convertida a posici�n visual (de "b2Vec2" a "Vector2f") y la rotaci�n convertida (radianes a grados)
	Vector2f posicion_fisica_convertida = { cuerpo->GetPosition().x * pixeles_por_metro, cuerpo->GetPosition().y * pixeles_por_metro };
	float rotacion_convertida = cuerpo->GetAngle() * (180.0f / b2_pi);

	//Establece la posici�n y rotaci�n con las unidades convertidas
	circulo_visual.setPosition(posicion_fisica_convertida);
	circulo_visual.setRotation(rotacion_convertida);

}

//M�todo que despierta o duerme al cuerpo, dependiendo el estado suministrado por par�metro
void Circulo::despertar(bool estado) {

	cuerpo->SetAwake(estado);

}

//Aplica una fuerza al centro del cuerpo, despertandolo en el proceso. Recibe la magnitud por par�metro
void Circulo::aplicarFuerza(b2Vec2 magnitud) {

	//Se aplica la fuerza usando la magnitud
	cuerpo->ApplyForceToCenter(magnitud, true);

}

//////////////////////////////////////////////////////////////////

//M�todo que devuelve el cuerpo f�sico del Circulo
b2Body* Circulo::retornarCuerpo() {

	return cuerpo;

}

//M�todo que devuelve la figura visual del Circulo
CircleShape* Circulo::retornarVisual() {

	return &circulo_visual;

}