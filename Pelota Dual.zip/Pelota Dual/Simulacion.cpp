#include "Simulacion.h"

//Constructor: Acepta como par�metros la dimension y el nombre de la ventana para el programa. Inicializa las variables y
//llama a m�todos de inicializaci�n
Simulacion::Simulacion(Vector2i dimensiones_programa, string nombre_programa) {

	//Iguala la variable de vector de dimension
	dimensiones_ventana = dimensiones_programa;

	//Iguala la variable de nombre
	nombre_ventana = nombre_programa;

	//Asigna una nueva ventana a la variable existente
	ventana = crearVentana(dimensiones_ventana.x, dimensiones_ventana.y, nombre_ventana);

	//Instancia el gestor de eventos
	gestor_eventos = new Event;

	//Se establece la gravedad y se suministra al mundo f�sico para su creaci�n
	gravedad = {0.0f, 0.05f};
	mundo = new b2World(gravedad);

	//Llamada a crear los elementos
	crearElementos();

	arrastrando = false;

}

//M�todo que llena los punteros a elementos con valores, instancia el soporte y la bola
void Simulacion::crearElementos() {

	//SOPORTE
	b2Vec2 dimensiones_pared = { 0.5f, 9.75f };
	b2Vec2 dimensiones_suelo = { 20.0f, 0.5f };

	//Creaci�n de los delimitantes de la simulaci�n
	paredes[0] = new Poligono(dimensiones_suelo, { 19.0f, 21.0f }, mundo, Color::Blue, false, PIXELES_POR_METRO); //Suelo
	paredes[1] = new Poligono(dimensiones_suelo, { 19.0f, 0.5f }, mundo, Color::Blue, false, PIXELES_POR_METRO); //Techo
	paredes[2] = new Poligono(dimensiones_pared, { 0.5f, 10.75f }, mundo, Color::Cyan, false, PIXELES_POR_METRO); //Pared izquierda
	paredes[3] = new Poligono(dimensiones_pared, { 38.0f, 10.75f }, mundo, Color::Cyan, false, PIXELES_POR_METRO); //Pared derecha

	////////////////////////////////////////////////////////////////////////////

	//PELOTAS
	float radio = 1.5f;

	//Crea las bolas A y B
	bolas[0] = new Circulo(radio, {17.0f, 14.0f}, mundo, Color::White, true, PIXELES_POR_METRO);
	bolas[1] = new Circulo(radio, { 21.0f, 14.0f }, mundo, Color::Yellow, true, PIXELES_POR_METRO);

	////////////////////////////////////////////////////////////////////////////

	//ENLACE
	enlace = new Enlace(bolas[0], bolas[1], b2Vec2_zero, b2Vec2_zero, mundo, PIXELES_POR_METRO);

}

//M�todo de bucle principal, en �l ocurre todo el manejo de la l�gica
void Simulacion::iniciarSimulacion() {

	//Mientras la ventana est� abierta...
	while (ventana->isOpen()) {

		//Llama a actualizar las f�sicas
		actualizarFisicas(10,8);

		//Ejecuta la gesti�n de eventos
		gestionarEventos();

		//Ejecuta la actualizaci�n del renderizado en la ventana
		actualizarRenderizado();

	}

}

//M�todo que genera una ventana con las dimensiones y nombre especificadas y luego la retorna para ser almacenada y usada
RenderWindow* Simulacion::crearVentana(int altura, int anchura, string nombre) {

	//Retorna una nueva ventana con los par�metros recibidos
	return new RenderWindow(VideoMode(anchura, altura), nombre);

}

//M�todo que recibe inserciones para dibujarlas en la pantalla, limpia y actualiza el contenido de la misma
void Simulacion::actualizarRenderizado() {

	//Limpia la pantalla
	ventana->clear();

	//Itera sobre el arreglo paredes
	for (int i = 0; i < 4; i++) {

		//Toma el dato sobre el que se est� iterando y lo a�ade para ser dibujado
		paredes[i]->renderizar(ventana);

	}

	//A�ade ambas bolas para ser dibujadas
	bolas[0]->renderizar(ventana);
	bolas[1]->renderizar(ventana);

	//A�ade el enlace para ser dibujado
	enlace->renderizar(ventana);

	//Muestra el contenido cargado
	ventana->display();

}

//M�todo encargado de procesar todos los inputs eventos del jugador sobre la ventana.
void Simulacion::gestionarEventos() {

	while (ventana->pollEvent(*gestor_eventos)) {

		//Creaci�n de variables de posici�n del cursor, de pantalla y posici�n convertida
		Vector2i posicion_cursor;
		Vector2f posicion_pantalla;
		b2Vec2 posicion_convertida;

		switch (gestor_eventos->type) {

			//Evento: Cerrar ventana
		case Event::Closed:

			ventana->close();

			break;

			//Evento: Bot�n del Mouse Presionado
		case Event::MouseButtonPressed:

			//Si la enumeraci�n del bot�n es "Izquierda"
			if (gestor_eventos->mouseButton.button == Mouse::Left) {

				//Creaci�n de variables de posici�n del cursor, de pantalla y posici�n convertida
				Vector2i posicion_cursor;
				Vector2f posicion_pantalla;
				b2Vec2 posicion_convertida;

				//Se almacena la posici�n del cursor y se convierte a posici�n de pantalla
				posicion_cursor = Mouse::getPosition(*ventana);
				posicion_pantalla = ventana->mapPixelToCoords(posicion_cursor);

				//La posici�n obtenida se convierte a un vector f�sico, usando una divisi�n sobre la escala pixeles por metro
				posicion_convertida = { posicion_pantalla.x / PIXELES_POR_METRO, posicion_pantalla.y / PIXELES_POR_METRO };

				//Se llama a depurar los clicks
				depurarClicks(posicion_convertida);

				//Itera sobre el arreglo de bolas
				for (int i = 0; i < 2; i++) {

					//Si la posici�n convertida est� dentro de la figura f�sica del objeto sobre el que se itera...
					if (bolas[i]->retornarCuerpo()->GetFixtureList()->TestPoint({ posicion_convertida.x, posicion_convertida.y })) {

						//Cambia el bool de arrastrar a verdadero
						arrastrando = true;

						objeto_seleccionado = bolas[i];

					}

				}

			}

			break;

		case Event::MouseMoved:
			
			//Se almacena la posici�n del cursor y se convierte a posici�n de pantalla
			posicion_cursor = Mouse::getPosition(*ventana);
			posicion_pantalla = ventana->mapPixelToCoords(posicion_cursor);

			//La posici�n obtenida se convierte a un vector f�sico, usando una divisi�n sobre la escala pixeles por metro
			posicion_convertida = { posicion_pantalla.x / PIXELES_POR_METRO, posicion_pantalla.y / PIXELES_POR_METRO };

			if (objeto_seleccionado == nullptr) { break; }
			
			if (arrastrando) {

				objeto_seleccionado->reposicionar(posicion_convertida);

			}
			
			break;

			//Evento: Bot�n del Mouse Soltado
		case Event::MouseButtonReleased:

			if (gestor_eventos->mouseButton.button == Mouse::Left) {

				if (objeto_seleccionado == nullptr) { break; }

				objeto_seleccionado->aplicarFuerza({0.0f, 1.0f});

				//Cambia el bool de arrastrado a false
				arrastrando = false;

			}

			break;

		}

	}

}

//M�todo que actualiza la simulaci�n fisica usando las iteraciones suministradas por par�metro
void Simulacion::actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion) {

	//Almacena el tiempo
	float tiempo = 1.0f / 60.0f;

	//Hace que el mundo f�sico avance, actualizado los objetos contenidos en �l
	mundo->Step(tiempo, iteraciones_velocidad, iteraciones_posicion);

	//Tras actualizar las fisicas llama a la sincronizaci�n de visuales
	actualizarObjetos();

}

//Encargado de actualizar la posici�n de los objetos visuales para encajar con la de sus contrapartes f�sicas
void Simulacion::actualizarObjetos() {

	//Itera sobre todas las paredes
	for (int i = 0; i < 4; i++) {

		//Actualiza la pared sobre la cual se est� iterando
		paredes[i]->actualizar(PIXELES_POR_METRO);

	}

	//Actualiza las bolas
	bolas[0]->actualizar(PIXELES_POR_METRO);
	bolas[1]->actualizar(PIXELES_POR_METRO);

	//Actualiza el enlace
	enlace->actualizar(PIXELES_POR_METRO);

}

//M�todo debug que imprime la posici�n y rotaci�n de un objeto por consola
void Simulacion::depurarTransformacion(Poligono objeto) {

	//Depura la posici�n f�sica y visual
	cout << "P. Fisica: " << objeto.retornarCuerpo()->GetPosition().x * PIXELES_POR_METRO << ", " << objeto.retornarCuerpo()->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "P. Visual: " << objeto.retornarVisual()->getPosition().x << ", " << objeto.retornarVisual()->getPosition().y << endl;

	//Depura la rotaci�n f�sica y visual
	cout << "R. Fisica: " << objeto.retornarCuerpo()->GetAngle() << endl;
	cout << "R. Visual: " << objeto.retornarVisual()->getRotation() * (b2_pi / 180.0f) << endl;

}

//M�todo debug que imprime la posici�n y rotaci�n de un objeto por consola
void Simulacion::depurarTransformacion(Circulo objeto) {

	//Depura la posici�n f�sica y visual
	cout << "P. Fisica: " << objeto.retornarCuerpo()->GetPosition().x * PIXELES_POR_METRO << ", " << objeto.retornarCuerpo()->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "P. Visual: " << objeto.retornarVisual()->getPosition().x << ", " << objeto.retornarVisual()->getPosition().y << endl;

	//Depura la rotaci�n f�sica y visual
	cout << "R. Fisica: " << objeto.retornarCuerpo()->GetAngle() << endl;
	cout << "R. Visual: " << objeto.retornarVisual()->getRotation() * (b2_pi / 180.0f) << endl;

}

//M�todo de depuraci�n que envia a consola qu� objeto ha sido clickeado por el rat�n
void Simulacion::depurarClicks(b2Vec2& posicion_convertida)
{
	//Si el click se ejecuta sobre el cuerpo A...
	if (bolas[0]->retornarCuerpo()->GetFixtureList()->TestPoint({ posicion_convertida.x, posicion_convertida.y })) {

		//Env�a la notificaci�n a consola
		cout << "[DEBUG]: Clickeado: Pelota A" << endl;

	}

	//Si el click se ejecuta sobre el cuerpo B...
	if (bolas[1]->retornarCuerpo()->GetFixtureList()->TestPoint({ posicion_convertida.x, posicion_convertida.y })) {

		//Env�a la notificaci�n a consola
		cout << "[DEBUG]: Clickeado: Pelota B" << endl;

	}
}