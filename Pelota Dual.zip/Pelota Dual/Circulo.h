#pragma once

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <box2d.h>
#include <iostream>

using namespace sf;
using namespace std;

class Circulo {

private:

	//Radio del circulo
	float radio;

	//Figura visual del circulo
	CircleShape circulo_visual;

	//Figura f�sica, definici�n del cuerpo y cuerpo del circulo
	b2CircleShape figura_cuerpo;
	b2BodyDef definicion_cuerpo;
	b2Body* cuerpo;

	//Definici�n de fijador y fijador del circulo
	b2FixtureDef definicion_fijador;
	b2Fixture* fijador;

public:

	//Constructores
	Circulo(b2World* mundo);
	Circulo(float radio, b2Vec2 posicion, b2World* mundo, Color color, bool es_dinamico, int pixeles_por_metro);

	//M�todos sin retorno
	void renderizar(RenderWindow* ventana);
	void crearFisicas(b2Vec2 posicion, b2World* mundo, bool es_dinamico);
	void crearVisuales(Color color, b2Vec2 posicion, int pixeles_por_metro);
	void actualizar(int pixeles_por_metro);
	void aplicarFuerza(b2Vec2 magnitud);
	void despertar(bool estado);
	void reposicionar(b2Vec2 nueva_posicion);

	//M�todos con retorno de dato
	b2Body* retornarCuerpo();
	CircleShape* retornarVisual();

};

