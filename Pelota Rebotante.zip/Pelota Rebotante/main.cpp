#include <iostream>
#include "Simulacion.h"

int main() {

    //Crea un objeto de clase Simulaci�n y lo ejecuta usando el m�todo de inicio
    Simulacion* programa = new Simulacion({1080, 1920}, "Pelota Rebotante");
    programa->iniciarSimulacion();

    return 0;

}