#include "Simulacion.h"

//Constructor: Acepta como par�metros la dimension y el nombre de la ventana para el programa. Inicializa las variables y
//llama a m�todos de inicializaci�n
Simulacion::Simulacion(Vector2i dimensiones_programa, string nombre_programa) {

	//Iguala la variable de vector de dimension
	dimensiones_ventana = dimensiones_programa;

	//Iguala la variable de nombre
	nombre_ventana = nombre_programa;

	//Asigna una nueva ventana a la variable existente
	ventana = crearVentana(dimensiones_ventana.x, dimensiones_ventana.y, nombre_ventana);

	//Instancia el gestor de eventos
	gestor_eventos = new Event;

	//Se establece la gravedad y se suministra al mundo f�sico para su creaci�n
	gravedad = {0.0f, 0.02f};
	mundo = new b2World(gravedad);

	//Llamada a crear los elementos
	crearElementos();

}

//M�todo que llena los punteros a elementos con valores, esencialmente instancia los objetos Pol�gono y Ragdoll para la simulaci�n
void Simulacion::crearElementos() {

	//PAREDES Y TECHOS
	// 
	//Guarda el tama�o de una pared y un suelo, usado para generar los 4 objetos
	b2Vec2 dimensiones_suelo = { 20.0f, 0.5f };
	b2Vec2 dimensiones_pared = { 0.5f, 9.75f };

	//Creaci�n de los delimitantes de la simulaci�n
	paredes[0] = new Poligono(dimensiones_suelo, { 19.0f, 21.0f }, mundo, Color::Blue, false, PIXELES_POR_METRO); //Suelo
	paredes[1] = new Poligono(dimensiones_suelo, { 19.0f, 0.5f }, mundo, Color::Blue, false, PIXELES_POR_METRO); //Techo
	paredes[2] = new Poligono(dimensiones_pared, { 0.5f, 10.75f }, mundo, Color::Cyan, false, PIXELES_POR_METRO); //Pared izquierda
	paredes[3] = new Poligono(dimensiones_pared, { 38.0f, 10.75f }, mundo, Color::Cyan, false, PIXELES_POR_METRO); //Pared derecha

	////////////////////////////////////////////////////////////////////////////

	//RAGDOLL
	// 
	//Guarda el tama�o de cada parte del mu�eco
	b2Vec2 dimensiones_componentes[6];
	dimensiones_componentes[0] = { 0.25f, 0.25f }; //Dimensiones: Cabeza
	dimensiones_componentes[1] = { 0.5f, 0.75f }; //Dimensiones: Cuerpo

	//Bucle de 4 iteraciones que recorre desde �ndice "2" hasta �ndice "5" para fijar el tama�o (Brazos y Piernas)
	for (int i = 2; i < 6; i++) {

		//Establece las dimensiones para cada �ndice
		dimensiones_componentes[i] = { 0.2f, 0.5f }; //Dimensiones: Brazos y Piernas

	}

	////////////////////////////////////////////////////////////////////////////

	//Almacena la posicion centro y en base a ella configura las posiciones iniciales para cada parte del cuerpo
	b2Vec2 posicion_centro = { 19.2f, 10.8f };
	b2Vec2 posiciones_componentes[6];
	posiciones_componentes[0] = { posicion_centro.x, posicion_centro.y - 1.0f }; //Posicion: Cabeza
	posiciones_componentes[1] = posicion_centro; //Posicion: Cuerpo
	posiciones_componentes[2] = { posicion_centro.x - 0.75f, posicion_centro.y - 0.25f }; //Posicion: Brazo Izquierdo
	posiciones_componentes[3] = { posicion_centro.x + 0.75f, posicion_centro.y - 0.25f }; //Posicion: Brazo Derecho
	posiciones_componentes[4] = { posicion_centro.x - 0.5f, posicion_centro.y + 1.25f }; //Posicion: Pierna Izquierda
	posiciones_componentes[5] = { posicion_centro.x + 0.5f, posicion_centro.y + 1.25f }; //Posicion: Pierna Derecha

	////////////////////////////////////////////////////////////////////////////

	//Establece los colores para cada parte del ragdoll
	Color colores[6];
	colores[0] = Color::White; //Color: Cabeza
	colores[1] = Color::Green; //Color: Cuerpo

	//Bucle de 4 iteraciones desde �ndice "2" hasta "5"
	for (int i = 2; i < 6; i++) {

		//Establece el color para cada �ndice
		colores[i] = Color::Yellow; //Color: Brazos y Piernas

	}

	////////////////////////////////////////////////////////////////////////////

	//Creaci�n del Ragdoll
	ragdoll = new Ragdoll(dimensiones_componentes, posiciones_componentes, mundo, colores, true, PIXELES_POR_METRO);

	//Aplica una primera fuerza para impulsar al ragdoll al suelo tras aparecer en el mundo
	ragdoll->aplicarFuerza({0.0f, 5.0f});

}

//M�todo que permite aplicar una fuerza lineal al cuerpo suministrado por par�metro, usando el valor
void Simulacion::aplicarFuerza(b2Body* cuerpo, b2Vec2 valor) {

	//Se aplica el impulso lineal (valor) al cuerpo en el punto de origen elegido, despertandolo si est� dormido
	cuerpo->ApplyForceToCenter(valor, true);

}

//M�todo de bucle principal, en �l ocurre todo el manejo de la l�gica
void Simulacion::iniciarSimulacion() {

	//Mientras la ventana est� abierta...
	while (ventana->isOpen()) {

		//Llama a actualizar las f�sicas
		actualizarFisicas(10,8);

		//Ejecuta la gesti�n de eventos
		gestionarEventos();

		//Ejecuta la actualizaci�n del renderizado en la ventana
		actualizarRenderizado();

	}

}

//M�todo que genera una ventana con las dimensiones y nombre especificadas y luego la retorna para ser almacenada y usada
RenderWindow* Simulacion::crearVentana(int altura, int anchura, string nombre) {

	//Retorna una nueva ventana con los par�metros recibidos
	return new RenderWindow(VideoMode(anchura, altura), nombre);

}

//M�todo que recibe inserciones para dibujarlas en la pantalla, limpia y actualiza el contenido de la misma
void Simulacion::actualizarRenderizado() {

	//Limpia la pantalla
	ventana->clear();

	//Itera sobre los 4 elementos en paredes
	for (int i = 0; i < 4; i++) {

		//Pasa la ventana al elemento con la llamada a renderizar
		paredes[i]->renderizar(ventana);

	}

	//Llama a renderizar el ragdoll pasando la ventana
	ragdoll->renderizar(ventana);

	//Muestra el contenido cargado
	ventana->display();

}

//M�todo encargado de procesar todos los inputs eventos del jugador sobre la ventana.
void Simulacion::gestionarEventos() {

	while (ventana->pollEvent(*gestor_eventos)) {

		switch (gestor_eventos->type) {

			//Evento: Cerrar ventana
		case Event::Closed:

			ventana->close();

			break;

			//Evento: Tecla Presionada
		case Event::KeyPressed:

			switch (gestor_eventos->key.code) {

				//Tecla: Espacio - Aplica fuerza vertical al Ragdoll
			case Keyboard::Space:

				//Aplica una fuerza hacia arriba en newtons al componente 1 (Cuerpo) del ragdoll
				ragdoll->aplicarFuerza({0.0f, -30.0f}, 1);

				break;

				//Tecla: D - Aplica fuerza horizontal positiva (Derecha)
			case Keyboard::D:

				//Aplica una fuerza a la derecha en newtons al componente 1 (Cuerpo) del ragdoll
				ragdoll->aplicarFuerza({30.0f, 0.0f}, 1);

				break;

				//Tecla: A - Aplica fuerza horizontal negativa (Izquierda)
			case Keyboard::A:

				//Aplica una fuerza a la izquierda en newtons al componente 1 (Cuerpo) del ragdoll
				ragdoll->aplicarFuerza({ -30.0f, 0.0f }, 1);

				break;
				
			}

		}

	}

}

//M�todo que actualiza la simulaci�n fisica usando las iteraciones suministradas por par�metro
void Simulacion::actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion) {

	//Almacena el tiempo
	float tiempo = 1.0f / 60.0f;

	//Hace que el mundo f�sico avance, actualizado los objetos contenidos en �l
	mundo->Step(tiempo, iteraciones_velocidad, iteraciones_posicion);

	//Tras actualizar las fisicas llama a la sincronizaci�n de visuales
	actualizarObjetos();

}

//Encargado de actualizar la posici�n de los objetos visuales para encajar con la de sus contrapartes f�sicas
void Simulacion::actualizarObjetos() {

	//Actualiza el ragdoll
	ragdoll->actualizar(PIXELES_POR_METRO);

	//Bucle que itera sobre cada elemento de paredes
	for (int i = 0; i < 4; i++) {

		//Actualiza cada elemento
		paredes[i]->actualizar(PIXELES_POR_METRO);

	}

}

//M�todo debug que imprime la posici�n y rotaci�n de un objeto por consola
void Simulacion::depurarTransformacion(Poligono objeto) {

	//Depura la posici�n f�sica y visual
	cout << "P. Fisica: " << objeto.retornarCuerpo()->GetPosition().x * PIXELES_POR_METRO << ", " << objeto.retornarCuerpo()->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "P. Visual: " << objeto.retornarVisual()->getPosition().x << ", " << objeto.retornarVisual()->getPosition().y << endl;

	//Depura la rotaci�n f�sica y visual
	cout << "R. Fisica: " << objeto.retornarCuerpo()->GetAngle() << endl;
	cout << "R. Visual: " << objeto.retornarVisual()->getRotation() * (b2_pi / 180.0f) << endl;

}