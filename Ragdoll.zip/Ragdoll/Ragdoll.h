#pragma once

#include "Poligono.h"
#include "Enlace.h"

class Ragdoll {

private:

	//El ragdoll est� compuesto por 6 objetos de tipo Pol�gono
	Poligono* componentes[6];
	Enlace* enlaces[5];

public:

	//Constructor
	Ragdoll(b2Vec2 dimensiones_poligono[6], b2Vec2 posicion[6], b2World* mundo, Color color[6], bool es_dinamico, int pixeles_por_metro);

	//M�todos sin retorno
	void renderizar(RenderWindow* ventana);
	void actualizar(int pixeles_por_metro);
	void crearEnlaces(b2World* mundo, int pixeles_por_metro);
	void aplicarFuerza(b2Vec2 magnitud);
	void aplicarFuerza(b2Vec2 magnitud, int indice_afectado);

	//M�todos que retornar un dato
	Poligono* retornarComponente(int indice);

};

